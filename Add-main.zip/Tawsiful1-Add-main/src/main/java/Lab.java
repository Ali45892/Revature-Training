
public class Lab {
    /**
     * Let's say we're making a calculator app!
     *
     * Instead of returning 0, this method should return the sum of two integers (ints).
     * Ints represent whole numbers in Java.
     *
     * @param a first number to be added.
     * @param b second number to be added.
     * @return the sum of a and b.
     */
    public int addNumbers(int a, int b){
        int s = a +b;
        return s;
    }
}